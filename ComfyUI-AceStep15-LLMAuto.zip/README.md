# ComfyUI-AceStep15-LLMAuto

Adds a new node, **TextEncodeAceStepAudio 1.5 (LLM Auto)**, which is a drop-in
alternative to the built-in `TextEncodeAceStepAudio1.5` node. It has the same
widgets, plus three optional text-socket inputs so `bpm`, `timesignature`,
and `keyscale` can be driven by an LLM node (e.g. Ollama Generate) instead of
only set manually.

This does **not** modify or replace any built-in ComfyUI node — it registers
a brand new node under `model/conditioning/audio`, so it installs safely
alongside your existing workflows.

## Installation

1. Copy this folder into your ComfyUI `custom_nodes` directory, e.g.:
   `ComfyUI/custom_nodes/ComfyUI-AceStep15-LLMAuto/`
2. Restart ComfyUI.
3. Search for "LLM Auto" or "TextEncodeAceStepAudio 1.5 (LLM Auto)" when adding a node.

## New inputs

- `bpm_override` (optional, STRING) — connect an LLM text output here. The first
  number found in the text is parsed as BPM (clamped 10–300). Falls back to the
  `bpm` widget if unconnected or unparseable.
- `timesignature_override` (optional, STRING) — the first number found is matched
  against valid time signatures (2, 3, 4, 6). Falls back to the `timesignature`
  widget if unconnected or invalid.
- `keyscale_override` (optional, STRING) — accepts free text like `"C# minor"`,
  `"Db Major"`, `"A flat major"` and normalizes it to a valid key/scale. Falls
  back to the `keyscale` widget if unconnected or unrecognized.

Leaving any override socket unconnected behaves identically to the original
built-in node.

## Requirements

Requires a version of ComfyUI with the ACE-Step 1.5 nodes (`comfy_api.latest`
IO/ComfyExtension API) already available, since this node depends on the
same `IO.Clip`, `IO.Conditioning`, and tokenizer behavior as the built-in
`TextEncodeAceStepAudio1.5` node.
