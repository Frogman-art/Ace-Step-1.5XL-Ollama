"""
ComfyUI-AceStep15-LLMAuto

A standalone custom node for ACE-Step 1.5 that adds optional text-socket
overrides for bpm, timesignature, and keyscale, so they can be driven by
an LLM (e.g. an Ollama Generate node) instead of only the manual widgets.

This does NOT modify or replace the built-in TextEncodeAceStepAudio1.5 node.
It registers a new node ("TextEncodeAceStepAudio15WithLLMOverrides") that
you use in place of the built-in one when you want LLM-driven values.
"""

import re

from typing_extensions import override

import node_helpers
from comfy_api.latest import ComfyExtension, IO


def _parse_bpm_override(value: str, default: int, min_v: int = 10, max_v: int = 300) -> int:
    """Pull the first integer out of a free-text LLM response and clamp it."""
    if value is None:
        return default
    match = re.search(r"\d+", value)
    if not match:
        return default
    return max(min_v, min(max_v, int(match.group())))


def _parse_timesignature_override(value: str, options: list, default: str) -> str:
    """Match the first number found (e.g. '4' from '4/4 time') against valid options."""
    if value is None:
        return default
    match = re.search(r"\d+", value)
    if match and match.group() in options:
        return match.group()
    return default


def _parse_keyscale_override(value: str, options: list, default: str) -> str:
    """Normalize free-text like 'c# minor', 'Db Major', 'A flat major' to a valid option."""
    if value is None:
        return default
    v = value.strip().lower()
    v = v.replace("-", " ").replace("_", " ")
    v = re.sub(r"\bsharp\b", "#", v)
    v = re.sub(r"\bflat\b", "b", v)
    v = re.sub(r"\bmaj\b", "major", v)
    v = re.sub(r"\bmin\b", "minor", v)
    v = re.sub(r"\s+", " ", v).strip()

    options_lower = {opt.lower(): opt for opt in options}
    if v in options_lower:
        return options_lower[v]

    # Try to salvage "<root><quality>" written with no space, e.g. "c#major"
    m = re.match(r"^([a-g][#b]?)\s*(major|minor)$", v)
    if m:
        candidate = f"{m.group(1)} {m.group(2)}"
        for opt in options:
            if opt.lower() == candidate:
                return opt

    return default


class TextEncodeAceStepAudio15WithLLMOverrides(IO.ComfyNode):
    @classmethod
    def define_schema(cls):
        return IO.Schema(
            node_id="TextEncodeAceStepAudio15WithLLMOverrides",
            display_name="TextEncodeAceStepAudio 1.5 (LLM Auto)",
            category="model/conditioning/audio",
            description=(
                "TextEncodeAceStepAudio 1.5 with optional text-socket overrides for "
                "bpm, timesignature, and keyscale, so they can be driven by an LLM "
                "(e.g. an Ollama node) instead of only the manual widgets."
            ),
            inputs=[
                IO.Clip.Input("clip"),
                IO.String.Input("tags", multiline=True, dynamic_prompts=True),
                IO.String.Input("lyrics", multiline=True, dynamic_prompts=True),
                IO.Int.Input("seed", default=0, min=0, max=0xffffffffffffffff, control_after_generate=True),
                IO.Int.Input("bpm", default=120, min=10, max=300),
                IO.Float.Input("duration", default=120.0, min=0.0, max=2000.0, step=0.1),
                IO.Combo.Input("timesignature", options=['2', '3', '4', '6']),
                IO.Combo.Input("language", options=['ar', 'az', 'bg', 'bn', 'ca', 'cs', 'da', 'de', 'el', 'en', 'es', 'fa', 'fi', 'fr', 'he', 'hi', 'hr', 'ht', 'hu', 'id', 'is', 'it', 'ja', 'ko', 'la', 'lt', 'ms', 'ne', 'nl', 'no', 'pa', 'pl', 'pt', 'ro', 'ru', 'sa', 'sk', 'sr', 'sv', 'sw', 'ta', 'te', 'th', 'tl', 'tr', 'uk', 'ur', 'vi', 'yue', 'zh', 'unknown'], default='en'),
                IO.Combo.Input("keyscale", options=[f"{root} {quality}" for quality in ["major", "minor"] for root in ["C", "C#", "Db", "D", "D#", "Eb", "E", "F", "F#", "Gb", "G", "G#", "Ab", "A", "A#", "Bb", "B"]]),
                IO.String.Input(
                    "bpm_override",
                    optional=True,
                    tooltip="Optional text input (e.g. from an Ollama node). If connected, its first number is parsed as BPM and overrides the bpm widget. Falls back to the widget if empty or unparseable.",
                ),
                IO.String.Input(
                    "timesignature_override",
                    optional=True,
                    tooltip="Optional text input (e.g. from an Ollama node). If connected, its first number is matched to a valid time signature (2, 3, 4, 6) and overrides the widget. Falls back to the widget if empty or invalid.",
                ),
                IO.String.Input(
                    "keyscale_override",
                    optional=True,
                    tooltip="Optional text input (e.g. from an Ollama node), e.g. 'C# minor' or 'Ab major'. If connected and it matches a valid key/scale, it overrides the widget. Falls back to the widget if empty or invalid.",
                ),
                IO.Boolean.Input("generate_audio_codes", default=True, tooltip="Enable the LLM that generates audio codes. This can be slow but will increase the quality of the generated audio. Turn this off if you are giving the model an audio reference.", advanced=True),
                IO.Float.Input("cfg_scale", default=2.0, min=0.0, max=100.0, step=0.1, advanced=True),
                IO.Float.Input("temperature", default=0.85, min=0.0, max=2.0, step=0.01, advanced=True),
                IO.Float.Input("top_p", default=0.9, min=0.0, max=2000.0, step=0.01, advanced=True),
                IO.Int.Input("top_k", default=0, min=0, max=100, advanced=True),
                IO.Float.Input("min_p", default=0.000, min=0.0, max=1.0, step=0.001, advanced=True),
            ],
            outputs=[IO.Conditioning.Output()],
        )

    @classmethod
    def execute(cls, clip, tags, lyrics, seed, bpm, duration, timesignature, language, keyscale,
                generate_audio_codes, cfg_scale, temperature, top_p, top_k, min_p,
                bpm_override=None, timesignature_override=None, keyscale_override=None) -> IO.NodeOutput:
        timesignature_options = ['2', '3', '4', '6']
        keyscale_options = [f"{root} {quality}" for quality in ["major", "minor"]
                             for root in ["C", "C#", "Db", "D", "D#", "Eb", "E", "F", "F#", "Gb", "G", "G#", "Ab", "A", "A#", "Bb", "B"]]

        resolved_bpm = _parse_bpm_override(bpm_override, bpm) if bpm_override else bpm
        resolved_timesignature = (
            _parse_timesignature_override(timesignature_override, timesignature_options, timesignature)
            if timesignature_override else timesignature
        )
        resolved_keyscale = (
            _parse_keyscale_override(keyscale_override, keyscale_options, keyscale)
            if keyscale_override else keyscale
        )

        tokens = clip.tokenize(tags, lyrics=lyrics, bpm=resolved_bpm, duration=duration, timesignature=int(resolved_timesignature), language=language, keyscale=resolved_keyscale, seed=seed, generate_audio_codes=generate_audio_codes, cfg_scale=cfg_scale, temperature=temperature, top_p=top_p, top_k=top_k, min_p=min_p)
        conditioning = clip.encode_from_tokens_scheduled(tokens)
        return IO.NodeOutput(conditioning)


class AceStep15LLMAutoExtension(ComfyExtension):
    @override
    async def get_node_list(self) -> list[type[IO.ComfyNode]]:
        return [
            TextEncodeAceStepAudio15WithLLMOverrides,
        ]


async def comfy_entrypoint() -> AceStep15LLMAutoExtension:
    return AceStep15LLMAutoExtension()
